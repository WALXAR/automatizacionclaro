﻿configuration MoveAzureTempDrive
{
    param(
		[Parameter(Mandatory)] 
        [string]$TempDriveLetter
		[string]$MachineName
    )

    Import-DscResource -ModuleName MoveAzureTempDrive, xComputerManagement

  Node $MachineName
  {
    # Install the Application-Server
WindowsFeature Application-Server
{
Ensure = "Present"
Name= "Application-Server"
}

# Install the AS-NET-Framework
WindowsFeature AS-NET-Framework
{
Ensure = "Present"
Name= "AS-NET-Framework"
}

# Install the AS-WAS-Support
WindowsFeature AS-WAS-Support
{
Ensure = "Present"
Name= "AS-WAS-Support"
}

# Install the AS-HTTP-Activation
WindowsFeature AS-HTTP-Activation
{
Ensure = "Present"
Name= "AS-HTTP-Activation"
}

# Install the AS-TCP-Activation
WindowsFeature AS-TCP-Activation
{
Ensure = "Present"
Name= "AS-TCP-Activation"
}

# Install the AS-Named-Pipes
WindowsFeature AS-Named-Pipes
{
Ensure = "Present"
Name= "AS-Named-Pipes"
}

# Install the File-Services
WindowsFeature File-Services
{
Ensure = "Present"
Name= "File-Services"
}

# Install the FS-FileServer
WindowsFeature FS-FileServer
{
Ensure = "Present"
Name= "FS-FileServer"
}

# Install the Web-Server
WindowsFeature Web-Server
{
Ensure = "Present"
Name= "Web-Server"
}

# Install the Web-WebServer
WindowsFeature Web-WebServer
{
Ensure = "Present"
Name= "Web-WebServer"
}

# Install the Web-Common-Http
WindowsFeature Web-Common-Http
{
Ensure = "Present"
Name= "Web-Common-Http"
}

# Install the Web-Static-Content
WindowsFeature Web-Static-Content
{
Ensure = "Present"
Name= "Web-Static-Content"
}

# Install the Web-Default-Doc
WindowsFeature Web-Default-Doc
{
Ensure = "Present"
Name= "Web-Default-Doc"
}

# Install the Web-Dir-Browsing
WindowsFeature Web-Dir-Browsing
{
Ensure = "Present"
Name= "Web-Dir-Browsing"
}

# Install the Web-Http-Errors
WindowsFeature Web-Http-Errors
{
Ensure = "Present"
Name= "Web-Http-Errors"
}

# Install the Web-App-Dev
WindowsFeature Web-App-Dev
{
Ensure = "Present"
Name= "Web-App-Dev"
}

# Install the Web-Asp-Net
WindowsFeature Web-Asp-Net
{
Ensure = "Present"
Name= "Web-Asp-Net"
}

# Install the Web-Net-Ext
WindowsFeature Web-Net-Ext
{
Ensure = "Present"
Name= "Web-Net-Ext"
}

# Install the Web-ISAPI-Ext
WindowsFeature Web-ISAPI-Ext
{
Ensure = "Present"
Name= "Web-ISAPI-Ext"
}

# Install the Web-ISAPI-Filter
WindowsFeature Web-ISAPI-Filter
{
Ensure = "Present"
Name= "Web-ISAPI-Filter"
}

# Install the Web-Health
WindowsFeature Web-Health
{
Ensure = "Present"
Name= "Web-Health"
}

# Install the Web-Http-Logging
WindowsFeature Web-Http-Logging
{
Ensure = "Present"
Name= "Web-Http-Logging"
}

# Install the Web-Log-Libraries
WindowsFeature Web-Log-Libraries
{
Ensure = "Present"
Name= "Web-Log-Libraries"
}

# Install the Web-Request-Monitor
WindowsFeature Web-Request-Monitor
{
Ensure = "Present"
Name= "Web-Request-Monitor"
}

# Install the Web-Http-Tracing
WindowsFeature Web-Http-Tracing
{
Ensure = "Present"
Name= "Web-Http-Tracing"
}

# Install the Web-Security
WindowsFeature Web-Security
{
Ensure = "Present"
Name= "Web-Security"
}

# Install the Web-Filtering
WindowsFeature Web-Filtering
{
Ensure = "Present"
Name= "Web-Filtering"
}

# Install the Web-Performance
WindowsFeature Web-Performance
{
Ensure = "Present"
Name= "Web-Performance"
}

# Install the Web-Stat-Compression
WindowsFeature Web-Stat-Compression
{
Ensure = "Present"
Name= "Web-Stat-Compression"
}

# Install the Web-Dyn-Compression
WindowsFeature Web-Dyn-Compression
{
Ensure = "Present"
Name= "Web-Dyn-Compression"
}

# Install the Web-Mgmt-Tools
WindowsFeature Web-Mgmt-Tools
{
Ensure = "Present"
Name= "Web-Mgmt-Tools"
}

# Install the Web-Mgmt-Console
WindowsFeature Web-Mgmt-Console
{
Ensure = "Present"
Name= "Web-Mgmt-Console"
}

# Install the Web-Mgmt-Compat
WindowsFeature Web-Mgmt-Compat
{
Ensure = "Present"
Name= "Web-Mgmt-Compat"
}

# Install the Web-Metabase
WindowsFeature Web-Metabase
{
Ensure = "Present"
Name= "Web-Metabase"
}

# Install the Web-WMI
WindowsFeature Web-WMI
{
Ensure = "Present"
Name= "Web-WMI"
}

# Install the Web-Lgcy-Scripting
WindowsFeature Web-Lgcy-Scripting
{
Ensure = "Present"
Name= "Web-Lgcy-Scripting"
}

# Install the Web-Lgcy-Mgmt-Console
WindowsFeature Web-Lgcy-Mgmt-Console
{
Ensure = "Present"
Name= "Web-Lgcy-Mgmt-Console"
}

# Install the NET-Framework
WindowsFeature NET-Framework
{
Ensure = "Present"
Name= "NET-Framework"
}

# Install the NET-Framework-Core
WindowsFeature NET-Framework-Core
{
Ensure = "Present"
Name= "NET-Framework-Core"
}

# Install the NET-Win-CFAC
WindowsFeature NET-Win-CFAC
{
Ensure = "Present"
Name= "NET-Win-CFAC"
}

# Install the NET-HTTP-Activation
WindowsFeature NET-HTTP-Activation
{
Ensure = "Present"
Name= "NET-HTTP-Activation"
}

# Install the NET-Non-HTTP-Activ
WindowsFeature NET-Non-HTTP-Activ
{
Ensure = "Present"
Name= "NET-Non-HTTP-Activ"
}

# Install the RSAT
WindowsFeature RSAT
{
Ensure = "Present"
Name= "RSAT"
}

# Install the RSAT-Role-Tools
WindowsFeature RSAT-Role-Tools
{
Ensure = "Present"
Name= "RSAT-Role-Tools"
}

# Install the RSAT-Web-Server
WindowsFeature RSAT-Web-Server
{
Ensure = "Present"
Name= "RSAT-Web-Server"
}

# Install the SNMP-Services
WindowsFeature SNMP-Services
{
Ensure = "Present"
Name= "SNMP-Services"
}

# Install the SNMP-Service
WindowsFeature SNMP-Service
{
Ensure = "Present"
Name= "SNMP-Service"
}

# Install the Telnet-Client
WindowsFeature Telnet-Client
{
Ensure = "Present"
Name= "Telnet-Client"
}

# Install the WAS
WindowsFeature WAS
{
Ensure = "Present"
Name= "WAS"
}

# Install the WAS-Process-Model
WindowsFeature WAS-Process-Model
{
Ensure = "Present"
Name= "WAS-Process-Model"
}

# Install the WAS-NET-Environment
WindowsFeature WAS-NET-Environment
{
Ensure = "Present"
Name= "WAS-NET-Environment"
}

# Install the WAS-Config-APIs
WindowsFeature WAS-Config-APIs
{
Ensure = "Present"
Name= "WAS-Config-APIs"
}


  }
    Node localhost 
    {

       LocalConfigurationManager 
       {
           RebootNodeIfNeeded = $True
       }      
               
        Script DisablePageFile
        {
        
            GetScript  = { @{ Result = "" } }
            TestScript = { 
               $pf=gwmi win32_pagefilesetting
               #There's no page file so okay to enable on the new drive
               if ($pf -eq $null)
               {
                    return $true
               }
               #Page file is still on the D drive
               if ($pf.Name.ToLower().Contains('d:'))
               {
                    return $false
               }

               else
               {
                    return $true
               }
            
            }
            SetScript  = {
                #Change temp drive and Page file Location 
                gwmi win32_pagefilesetting
                $pf=gwmi win32_pagefilesetting
                $pf.Delete()
                Restart-Computer -Force
            }
           
        }

	   MoveAzureTempDrive MoveAzureTempDrive
       {
		   TempDriveLetter = $TempDriveLetter           
       }
      
	}
}


